import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Main {
	Scheduler scheduler = new Scheduler();
	Interpreter interpreter = new Interpreter();
	
	static int time = 0;
	int currSlice = 0;
	final int quantum = 3;
	Program currentExecuting;
	static ArrayList<Program> programs = new ArrayList<Program>();

	public Main() {

	}

	public void executeLine(Program p) {
		interpreter.parse(p);

	}

	public static void checkArrivalTime() {
		boolean flag = false;
		Program temp = null;
		for (Program p : programs) {
			if (time == p.getArrivalTime()) {
				Scheduler.addToReady(p,Operating_System.getGeneralReady());
				flag = true;
				temp = p;
			}
		}
		if (flag) {
			programs.remove(temp);
		}
	}

	public void start() {
		Program p1 = new Program("Program_1.txt", 0);
		Program p2 = new Program("Program_2.txt", 1);
		Program p3 = new Program("Program_3.txt", 2);
		programs.add(p1);
		programs.add(p2);
		programs.add(p3);
		boolean flag = false;
		while (Operating_System.generalReady.isEmpty()) {
			for (Program p : programs) {
				if (time == p.getArrivalTime()) {
					Scheduler.addToReady(p,Operating_System.getGeneralReady());
					programs.remove(p);
					flag = true;
					break;
				}
			}
			if (!flag) {
				System.out.println("Current Clock Cycles: " + time);
				System.out.println("No Program is executing");
				System.out.println();
				time++;
			}
		}
		currentExecuting = scheduler.chooseNext();
		while (!Operating_System.generalReady.isEmpty() || !programs.isEmpty() || !Operating_System.generalBlocked.isEmpty()
				|| currentExecuting != null) {

			while ((currSlice < quantum && !Operating_System.generalBlocked.contains(currentExecuting)
					&& !currentExecuting.getProgramLines().isEmpty())) {
				System.out.println();
				System.out.println("Current Program: " + currentExecuting.getName());
				System.out.println("Current Clock Cycles: " + time);
				executeLine(currentExecuting);
				System.out.println("Ready Queue: " + Operating_System.generalReady);
				System.out.println("Blocked Queue: " + Operating_System.generalBlocked);
				currSlice++;
				time++;
				checkArrivalTime();
			}
			if (!Operating_System.generalBlocked.contains(currentExecuting))
				Operating_System.generalReady.add(currentExecuting);
			if (currSlice == quantum || currentExecuting.getProgramLines().isEmpty()
					|| Operating_System.generalBlocked.contains(currentExecuting)) {
				currentExecuting = scheduler.chooseNext();
				currSlice = 0;
			}
			while (!programs.isEmpty() && Operating_System.generalReady.isEmpty() && currentExecuting == null) {
				System.out.println();
				System.out.println("Current Clock Cycles: " + time);
				System.out.println("No Program executing");
				System.out.println();
				time++;
				checkArrivalTime();
				currentExecuting = scheduler.chooseNext();
			}

		}
		System.out.println();
		System.out.println("End Of Execution");

	}

	public static void main(String[] args) {
		Main main = new Main();
		main.start();
	}
}
