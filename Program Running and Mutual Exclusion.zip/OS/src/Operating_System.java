import java.util.LinkedList;
import java.util.Queue;

public class Operating_System {
	public Operating_System() {

	}
	public static Queue<Program> getGeneralBlocked() {
		return generalBlocked;
	}
	public static Queue<Program> getGeneralReady() {
		return generalReady;
	}
	static Queue<Program> generalBlocked = new LinkedList<Program>();
	static Queue<Program> generalReady = new LinkedList<Program>();
	Mutex accessFile = new Mutex(null);
	Mutex userInput = new Mutex(null);
	Mutex userOutput = new Mutex(null);

	public void assign(Program p, String[] instruction) {
		if (instruction.length == 4) { // assign b readfile a
			String data = SystemCalls.readDataFromMemory(p, instruction[3]);
			SystemCalls.writeDataToMemory(p, instruction[1], p.getReadFile());
		} else if (instruction[2].equals("input")) {
			SystemCalls.writeDataToMemory(p, instruction[1], p.getInput());
		} else {
			String data = SystemCalls.readDataFromMemory(p, instruction[2]);
			SystemCalls.writeDataToMemory(p, instruction[1], data);
		}
	}
	public void writeFile(Program p,String[] instruction) {
		String temp = "";
		String temp1 = "";
		for (Variable v : p.getVariables()) {
			if (v.getName().equals(instruction[1])) {
				temp = v.getStringData();
			}
			if (v.getName().equals(instruction[2])) {
				temp1 = v.getStringData();
			}
		}
		SystemCalls.writeFileToDisk(temp + ".txt", temp1);
	}
	public boolean semWait(Mutex m, Program p) {
		boolean flag = false;
		if (m.getValue() == mutexValue.one) {
			m.setOwnerID(p.getName());
			m.setValue(mutexValue.zero);
			if (generalBlocked.contains(p)) {
				generalBlocked.remove(p);
			}
		} else if (m.getOwnerID().equals(p.getName())) {
			return flag;
		} else if (!m.getQueue().contains(p)) {
			generalReady.remove(p);
			generalBlocked.add(p);
			m.getQueue().add(p);
		}
		if (m.getQueue().contains(p)) {
			flag = true;
		}

		return flag;
	}

	public void semSignal(Mutex m, Program p) {
		if (m.getOwnerID().equals(p.getName())) {
			if (!m.getQueue().isEmpty()) {
				Program temp = m.getQueue().remove();
				generalReady.add(temp);
				generalBlocked.remove(temp);
				m.setOwnerID(temp.getName());
				return;
			}
			m.setValue(mutexValue.one);
		}
	}
	public void input(Program p) {
		p.setInput(SystemCalls.input());
	}
	public void printData(Program p, String[] instruction) {
		SystemCalls.printData(p, instruction[1]);
		
	}
	public void printFromTo(Program p, String[] instruction) {
		int num1 = -1;
		int num2 = -1;
		num1 = Integer.parseInt(SystemCalls.readDataFromMemory(p, instruction[1]));
		num2 = Integer.parseInt(SystemCalls.readDataFromMemory(p, instruction[2]));
		if (num1 > num2) {
			for (int i = num1; i >= num2; i--) {
				SystemCalls.printData(i + "");
			}
		}
		if (num1 < num2) {
			for (int i = num1; i <= num2; i++) {
				SystemCalls.printData(i + "");
			}
		}
	}
	public void readFile(Program p, String[] instruction) {
		String fileName = SystemCalls.readDataFromMemory(p,instruction[1]);
		p.setReadFile(SystemCalls.readFileFromDisk(fileName));
	}
}
