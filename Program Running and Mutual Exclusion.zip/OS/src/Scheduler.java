import java.util.LinkedList;
import java.util.Queue;

public class Scheduler {
	Queue<Program> readyQueue;

	public Scheduler() {
	}

	public Program chooseNext() {
		for (Program p : Operating_System.generalReady) {
			if (p.getProgramLines().isEmpty()) {
				Operating_System.generalReady.remove(p);
				System.out.println("\n" + p.getName() + " finished Execution");
			}
		}
		if (Operating_System.generalReady.isEmpty()) {
			return null;
		} else {
			Program temp = Operating_System.generalReady.remove();
			return temp;
		}
	}

	public static void addToReady(Program p,Queue<Program> generalReady) {
		generalReady.add(p);
	}



}
