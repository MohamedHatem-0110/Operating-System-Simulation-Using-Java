import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class Program {
	private ArrayList<Variable> variables= new ArrayList<Variable>();
	private String fileSource;
	private String name;
	private String input;
	private String readFile;
	private int currentValue;
	private int maximum;
	private int pc = 0;
	private Stack<String> programLines = new Stack<String>();
	private Stack<String> temp = new Stack<String>();
	private int arrivalTime;

	public String getReadFile() {
		return readFile;
	}

	public void setReadFile(String readFile) {
		this.readFile = readFile;
	}

	public Stack<String> getProgramLines() {
		return programLines;
	}

	public void setProgramLines(Stack<String> programLines) {
		this.programLines = programLines;
	}

	
	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public Program(String fileSource, int arrivalTime) {
		this.fileSource = fileSource;
		this.name = fileSource.replace(".txt", "");
		this.arrivalTime=arrivalTime;
		File file = new File(fileSource);
		Scanner scan;
		try {
			scan = new Scanner(file);
			while (scan.hasNext()) {
				String line = scan.nextLine();
				String[] split = line.split(" ");
				if (split.length == 4) {//readfile a
					temp.push(split[2] + " " + split[3]);
					temp.push(line);
					continue;
				} else if(split.length == 3) {
					//input 
					if(split[2].equals("input")) {
						temp.push(split[2]);
						temp.push(line);
						continue;
					}	
				}					
				temp.push(line);
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		while(!temp.isEmpty()) {
			
			programLines.push(temp.pop());
		}
			
	}
	
	public int getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(int arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public ArrayList<Variable> getVariables() {
		return variables;
	}
	public void setVariables(ArrayList<Variable> arrayList) {
		this.variables = arrayList;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String toString() {
		return name;
	}
	
	public static void main(String[] args) {
		File file = new File("p1.txt");
		Scanner scan;
		try {
			scan = new Scanner(file);
			scan.nextLine();
			System.out.println(scan.hasNext());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
}
