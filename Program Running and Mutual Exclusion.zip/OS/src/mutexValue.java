
public enum mutexValue {
	one, zero;
}
